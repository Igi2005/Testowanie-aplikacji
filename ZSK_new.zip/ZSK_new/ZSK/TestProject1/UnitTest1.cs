using Domain.NewDirectory;
using Domain.VeryNewDirectory;
using Microsoft.VisualStudio.TestPlatform.TestHost;

namespace TestProject1
{
    public class UnitTest1
    {
        [Theory]
        [InlineData(1.0, true)]
        [InlineData(0.0, true)]
        [InlineData(0.1, true)]
        [InlineData(-0.1, false)]
        [InlineData(-1.0, false)]
        public void ShoulDepositMoneyIntoEmptyBankAccount(double moneyToDeposit, bool shouldDeposit)
        {
            BankAccount bankAccount = new BankAccount();
            var isDeposited = bankAccount.Deposit(moneyToDeposit);
            Assert.Equal(shouldDeposit, isDeposited);
        }

        [Theory]
        [InlineData(1.1, 1.1)]
        public void AddingMoney(double addMoney, double shouldBe)
        {
            BankAccount bankAccount = new BankAccount();

            bankAccount.Deposit(addMoney);
            var currentBalance = bankAccount.GetBalance();
            Assert.Equal(shouldBe, currentBalance);
        }
        [Theory]
        [InlineData(18, 12, 6)]
        public void TestingGCD(int a, int b, int expexted)
        {

            int actual = GreatestCommonDivisor.GCDiterative(a, b);

            Assert.Equal(expexted, actual);
        }
        [Theory]
        [InlineData(3, 5, 5, 3)]
        [InlineData(int.MinValue, int.MaxValue, int.MaxValue, int.MinValue)]
        public void TestingSwap(int x, int y, int expectedX, int expectedY)
        {

            int resultX, resultY;

            NumberSwap.MagicVariableSwap(x, y, out resultX, out resultY);

            Assert.Equal(expectedX, resultX);
            Assert.Equal(expectedY, resultY);

        }
    }
}