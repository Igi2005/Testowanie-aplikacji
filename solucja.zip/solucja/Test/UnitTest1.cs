using Xunit;
using projekt.Core.Services;
using projekt.Shared.Entities;
namespace Test
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {
            var service = new TextStatisticsSevice();
            var text = "Dobry tescik nie jest zly";
            var result = service.CountStatistics(text);

            Assert.Equal(25, result.AllSymbolCount);
            Assert.Equal(6, result.UniqueSymbolCount);
            Assert.Equal(2.634, result.Entropy);
        }
    }
}