﻿namespace projekt.Core
{
    public class Class1
    {

    }
}