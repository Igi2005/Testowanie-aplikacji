﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projekt.Shared.Entities
{
    public class TextAnalyzeResult
    {

        public int lenG;
        public string w1 = "";
        public string w2 = "";
        public string w3 = "";
    }
}
