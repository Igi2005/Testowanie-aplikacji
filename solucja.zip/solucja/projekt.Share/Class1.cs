﻿namespace projekt.Share
{
    public class Class1
    {

    }
}